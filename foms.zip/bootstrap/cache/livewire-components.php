<?php return array (
  'fomrations' => 'App\\Http\\Livewire\\Fomrations',
  'inscrire' => 'App\\Http\\Livewire\\Inscrire',
);