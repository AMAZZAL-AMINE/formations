

<?php $__env->startSection('content'); ?>
    <?php if(session()->has('message')): ?>
        <div class="alert bg-info text-white font-weight-bold">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('delete')): ?>
        <div class="alert bg-danger text-white font-weight-bold">
            <?php echo e(session('delete')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <h1 class="card-title">All Students</h1>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th> Name </th>
                                    <th> Cin </th>
                                    <th> Phone </th>
                                    <th> Formation </th>
                                    <th> Created At </th>
                                    <th>Profile</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($student->name); ?></td>
                                        <td><?php echo e($student->cin); ?></td>
                                        <td><?php echo e($student->phone); ?></td>
                                        <td class="text-muted"><?php echo e($student->formation->name); ?></td>
                                        <td><label
                                                class="badge badge-gradient-success"><?php echo e($student->created_at->format('d-m-Y')); ?></label>
                                        </td>
                                        <td>
                                            <button class="btn btn-gradient-info btn-rounded btn-icon">
                                                <i class="mdi mdi-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lv-projects\Formations\resources\views/admin/students/students.blade.php ENDPATH**/ ?>