<div class="register_group">
    <div class="group_left">
        <img src="<?php echo e(asset("images/re.png")); ?>" alt="">
        <div> <b>Inscrivez-vous, n'attendez pas</b></div>
    </div> 
        <form action="<?php echo e(route("student.store")); ?>"  class="group_right" method="post" >
            <?php echo csrf_field(); ?>
           
            <div>
                <label for="username">Username</label>
                <input type="text" wire:model="username" name="username">
                <?php $__errorArgs = ["username"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="cin">Cin</label>
                <input type="text" wire:model="cin" name="cin" >
                <?php $__errorArgs = ["cin"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="cin">Image Cin</label>
                <input type="file" wire:model="cin_img" name="cin_img">
                <?php $__errorArgs = ["cin_img"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="phone">Phone Number</label>
                <input type="number" wire:model="phone" name="phone">
                <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="username">Fomration</label>
                <select wire:model="formation" name="formation" >
                    <option value="Q">Fomration Assagbi Hiya hadi</option>
                    <option value="W">Fomration Assagbi Hiya hadi</option>
                    <option value="E">Fomration Assagbi Hiya hadi</option>
                    <option value="D">Fomration Assagbi Hiya hadi</option>
                </select>
                <?php $__errorArgs = ["formation"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="username">Type d'étude</label>
                <select wire:model="type_learn" name="type_learn" >
                    <option value="D">études à distance</option>
                    <option value="X">Étudier en présence</option>
                </select>
                <?php $__errorArgs = ["type_learn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit">Inscrire</button>
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lv-projects\Formations\resources\views/livewire/inscrire.blade.php ENDPATH**/ ?>