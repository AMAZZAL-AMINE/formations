

<?php $__env->startSection("content"); ?>
    <div>
        Hello World
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lv-projects\Formations\resources\views/pages/fromations.blade.php ENDPATH**/ ?>