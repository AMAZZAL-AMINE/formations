

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("/css/register.css")); ?>">
    <?php if(session()->has('message')): ?>
        <div class="alert alert-primary alert-dismissible fade show" role="alert">
          <strong><?php echo e(session("message")); ?></strong> 
        </div>
        
        <script>
          $(".alert").alert();
        </script>       
    <?php endif; ?>
    <div class="register_group">
    <div class="group_left">
        <img src="<?php echo e(asset("images/re.png")); ?>" alt="">
        <div> <b>Inscrivez-vous, n'attendez pas</b></div>
    </div> 
        <form action="<?php echo e(route("student.store")); ?>"  class="group_right" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
           
            <div>
                <label for="username">Username</label>
                <input type="text" name="username">
                <?php $__errorArgs = ["username"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="cin">Cin</label>
                <input type="text"  name="cin" >
                <?php $__errorArgs = ["cin"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="cin">Image Cin</label>
                <input type="file"  name="cin_img">
                <?php $__errorArgs = ["cin_img"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="phone">Phone Number</label>
                <input type="number"  name="phone">
                <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="username">Fomration</label>
                <select  name="formation" >
                    <option value="1">Fomration Assagbi Hiya hadi</option>
                    <option value="2">Fomration Assagbi Hiya hadi</option>
                    <option value="3">Fomration Assagbi Hiya hadi</option>
                    <option value="4">Fomration Assagbi Hiya hadi</option>
                </select>
                <?php $__errorArgs = ["formation"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="username">Type d'étude</label>
                <select  name="type_learn" >
                    <option value="b">études à distance</option>
                    <option value="a">Étudier en présence</option>
                </select>
                <?php $__errorArgs = ["type_learn"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">*<?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit">Inscrire</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lv-projects\Formations\resources\views/pages/register.blade.php ENDPATH**/ ?>