@extends("layouts.admin")

@section("content")

    <livewire:fomrations />
@endsection