@extends("layouts.admin")

@section("content")
    <div>
        <h1>Hello world</h1>
    </div>
@endsection