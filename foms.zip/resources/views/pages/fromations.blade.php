@extends("layouts.app")

@section("content")
    <div>
        Hello World
    </div>
@endsection